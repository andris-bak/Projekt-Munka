using Godot;
using System;


public partial class Main : Node2D
{
	Random rnd = new Random();
	private int score = 0;
	private int coin = 0;
	private int hp = 10;
	private int level = 1;
	private int levelprice = 2;
	private int min = 10;
	private int max = 20;
	private int counter = 1;
	private Player player;
	private Enemy enemy;
	
	[Export]
	public Label ScoreLabel;
	[Export]
	public Label CoinLabel;
	[Export]
	public Label HPLabel;
	[Export]
	public ProgressBar HPBar;
	[Export]
	public Label LevelLabel;
	[Export]
	public Label LevelPrice;
	
	public override void _Ready()
	{
		player = new Player();
		enemy = new Enemy();
		hp = enemy.Health;
		HPBar.MaxValue = enemy.Health;
		HPBar.Value = enemy.Health;
		HPBar.Step = player.Damage;
		UpdateScoreLabel();
		UpdateCoinLabel();
		UpdateHP();
		UpdateLevel();
		UpdateLevelPrice();
		

	}
	
	public void OnClickButton()
	{
		score++;
		hp -= player.Damage;
		UpdateHP();
		UpdateScoreLabel();
		if(hp <= 0)
		{
			coin += counter;
			score = 0;
			hp = rnd.Next(min,max);
			HPBar.MaxValue = hp;
			UpdateScoreLabel();
			UpdateCoinLabel();
			UpdateHP();
		}
	}
	
	public void OnLevelClickButton()
	{
		if (coin >= levelprice)
		{
			min = min * 2;
			max = max * 2;
			level++;
			player.LevelUp();
			coin = coin-levelprice;
			levelprice = levelprice * 2;
			counter++;
			hp = rnd.Next(min, max);
			HPBar.MaxValue = hp;
			UpdateCoinLabel();
			UpdateLevel();
			UpdateLevelPrice();
			UpdateHP();
		}
		
	}
	
	private void UpdateScoreLabel()
	{
		if (ScoreLabel != null)
		{
			ScoreLabel.Text = "Pontok: " + score.ToString();
		}
		
	}
	
	private void UpdateLevel()
	{
		if (LevelLabel != null)
		{
			LevelLabel.Text = "Level: " + level.ToString();
		}
		
	}
	
	private void UpdateLevelPrice()
	{
		if (LevelPrice != null)
		{
			LevelPrice.Text = "Price: " + levelprice.ToString();
		}
		
	}
	
	private void UpdateCoinLabel()
	{
		if(CoinLabel != null)
		{
			CoinLabel.Text = "Coins: " + coin.ToString();
		}
	}
	
	private void UpdateHP()
	{
		if(hp <= HPBar.MaxValue && hp >= 0)
		{
			if (HPLabel != null)
			{
				HPLabel.Text = "Health: " + hp.ToString();
			}
		}
		if (HPBar != null)
		{
			HPBar.Value = Math.Max(0, hp);
		}
	}
}

using Godot;
using System;

public partial class MainMenu : Node2D
{
	public void OnStartButtonPressed()
	{
		GetTree().ChangeSceneToFile("res://main.tscn");
	}

	public void OnQuitButtonPressed()
	{
		GetTree().Quit();
	}
}

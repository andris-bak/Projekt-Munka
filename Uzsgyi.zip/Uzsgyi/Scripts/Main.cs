using Godot;
using System;


public partial class Main : Node2D
{
	private int score = 0;
	private int coin = 0;
	private int hp = 10;
	private int level = 1;
	private int levelprice = 2;
	private Player player;
	
	[Export]
	public Label ScoreLabel;
	[Export]
	public Label CoinLabel;
	[Export]
	public Label HPLabel;
	[Export]
	public ProgressBar HPBar;
	[Export]
	public Label LevelLabel;
	[Export]
	public Label LevelPrice;
	
	public override void _Ready()
	{
		player = new Player();
		UpdateScoreLabel();
		UpdateCoinLabel();
		UpdateHP();
		UpdateLevel();
		UpdateLevelPrice();
		
		HPBar.MaxValue = 10;
		if(HPBar != null)
		{
			HPBar.MaxValue = 10;
			HPBar.Value = hp;
			HPBar.Step = player.Damage;
		}
	}
	
	public void OnClickButton()
	{
		score++;
		hp -= player.Damage;
		UpdateHP();
		UpdateScoreLabel();
		if(hp <= 0)
		{
			coin++;
			score = 0;
			hp = 10;
			UpdateScoreLabel();
			UpdateCoinLabel();
			UpdateHP();
		}
	}
	
	public void OnLevelClickButton()
	{
		if (coin >= 2)
		{
			level++;
			player.LevelUp();
			coin = coin-2;
			UpdateCoinLabel();
			UpdateLevel();
			UpdateLevelPrice();
		}
		
	}
	
	private void UpdateScoreLabel()
	{
		if (ScoreLabel != null)
		{
			ScoreLabel.Text = "Pontok: " + score.ToString();
		}
		
	}
	
	private void UpdateLevel()
	{
		if (LevelLabel != null)
		{
			LevelLabel.Text = "Level: " + level.ToString();
		}
		
	}
	
	private void UpdateLevelPrice()
	{
		if (LevelPrice != null)
		{
			LevelPrice.Text = "Price: " + levelprice.ToString();
		}
		
	}
	
	private void UpdateCoinLabel()
	{
		if(CoinLabel != null)
		{
			CoinLabel.Text = "Coins: " + coin.ToString();
		}
	}
	
	private void UpdateHP()
	{
		if(hp <= HPBar.MaxValue && hp >= 0)
		{
			if (HPLabel != null)
			{
				HPLabel.Text = "Health: " + hp.ToString();
			}
		}
		if (HPBar != null)
		{
			HPBar.Value = Math.Max(0, hp);
		}
	}
}
